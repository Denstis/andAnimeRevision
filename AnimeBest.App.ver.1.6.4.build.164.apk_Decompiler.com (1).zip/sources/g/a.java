package g;

/* JADX INFO: loaded from: classes.dex */
public final class a extends b {
}
