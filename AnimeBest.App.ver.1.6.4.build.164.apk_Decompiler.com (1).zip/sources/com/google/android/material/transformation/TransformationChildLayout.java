package com.google.android.material.transformation;

import android.content.Context;
import android.util.AttributeSet;
import com.google.android.material.circularreveal.CircularRevealFrameLayout;

/* JADX INFO: loaded from: classes.dex */
public class TransformationChildLayout extends CircularRevealFrameLayout {
    public TransformationChildLayout(Context context) {
        this(context, null);
    }

    public TransformationChildLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }
}
