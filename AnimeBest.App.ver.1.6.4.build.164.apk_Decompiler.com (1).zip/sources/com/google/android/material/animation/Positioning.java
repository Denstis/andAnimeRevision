package com.google.android.material.animation;

/* JADX INFO: loaded from: classes.dex */
public class Positioning {
    public final int gravity;
    public final float xAdjustment;
    public final float yAdjustment;

    public Positioning(int i2, float f2, float f3) {
        this.gravity = i2;
        this.xAdjustment = f2;
        this.yAdjustment = f3;
    }
}
