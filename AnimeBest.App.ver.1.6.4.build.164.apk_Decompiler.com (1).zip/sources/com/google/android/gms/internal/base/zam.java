package com.google.android.gms.internal.base;

/* JADX INFO: loaded from: classes.dex */
public final class zam {
    private static final zal zarp;
    private static volatile zal zarq;

    static {
        zao zaoVar = new zao();
        zarp = zaoVar;
        zarq = zaoVar;
    }

    public static zal zacv() {
        return zarq;
    }
}
