package com.google.android.gms.internal.base;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

/* JADX INFO: loaded from: classes.dex */
final class zao implements zal {
    private zao() {
    }

    @Override // com.google.android.gms.internal.base.zal
    public final ExecutorService zaa(int i2, ThreadFactory threadFactory, int i3) {
        return Executors.newFixedThreadPool(2, threadFactory);
    }
}
